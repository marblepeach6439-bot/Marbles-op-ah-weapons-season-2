# Marbles OP Weapons 2
Paper 1.21.4+ plugin + resource pack.

## Weapons
**Lifestealer** (`/marbleweapons give lifestealer`)
- Healthy Boi: right-click, double current health 30s (60s cooldown)
- Lifesteal: +half heart per kill, resets on death / losing blade
- Life Leach: heal 50% of damage dealt

![Lifestealer](images/lifestealer-original.jpeg)

## Download
Go to **Actions** -> latest run -> Artifacts, or **Releases** after tagging (`git tag v1.0 && git push --tags`).
- `MarblesOPWeapons2-1.0.jar` -> server `plugins/` folder
- `MarblesOPWeapons2-ResourcePack.zip` -> host it and set `resource-pack=` in server.properties
